Docker Repository
=================

For Docker please see https://github.com/cowrie/docker-cowrie/
