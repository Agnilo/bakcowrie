# setup version
from ._version import __version__ as version

__version__: str = version.short()
